+==============================================================================+
| IDENTIFICAÇÃO DOS ELEMENTOS DO GRUPO                                         |
+==============================================================================+

Carlos Manuel Carvalho Boavista Samouco
up201305187@fe.up.pt

Diogo Belarmino Coelho Marques
up201305642@fe.up.pt

José Alexandre Barreira Santos Teixeira
up201303930@fe.up.pt

+==============================================================================+
| INSTRUÇÕES DE EXECUÇÂO                                                       |
+==============================================================================+

(Executar)

Na pasta "Assembly" encontram-se os ficheiros executáveis do projeto, nomeadamente
ChatupClient.exe (aplicação cliente), ChatupServer.exe (aplicação servidor), bem
como um ficheiro SQLite já com informação preenchida (ChatupServer.db).

Para testar basta executar uma instância do servidor ao lado de uma ou várias
instâncias da aplicação cliente.

(Compilar)

Abrir ficheiro solution (.sln) no Visual Studio (versão 2013 ou superior).
Antes de fazer build, mudar a "Active solution plaform" de "Any CPU" para "x64",
pois uma das bibliotecas (System.Data.SQLite.dll) utiliza código nativo em C++.
Se os erros de compilação ou na execução persistirem, fazer download da biblioteca
em questão, adicionando manualmente às references do projeto ChatupServer.
[https://system.data.sqlite.org/index.html/doc/trunk/www/index.wiki]

(Login)

Username: marques999
Password: 14191091

Username: jabst
Password: m80terino

Username: somouco
Password: dormirebom666

Username: koreris
Password: sailorkujobeans

Username: digpinto
Password: misterio